import pandas as pd
import numpy as np
from collections import Counter
import math

df = pd.read_csv("utils_exercise02/data_entropy_binary.csv")
df
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

plt.figure(figsize=(12, 4))

x_colors = ['blue' if val == 1 else 'red' for val in df.x_label]

plt.subplot(1, 2, 1)  
plt.scatter(df.x_1, df.x_2, color=x_colors)
plt.title('x1 vs x2')
plt.xticks(range(-1,2))
plt.xlabel('x1')
plt.yticks(range(-2,3,2))
plt.ylabel('x2')

legend_handles = [
    plt.scatter([], [], color='red', label='0'),
    plt.scatter([], [], color='blue', label='1')
]

plt.legend(handles=legend_handles, title="Category")



y_colors = ['blue' if val == 1 else 'red' for val in df.y_label]
plt.subplot(1, 2, 2)  
plt.scatter(df.y_1, df.y_2, color= y_colors)
plt.title('y1 vs y2')
plt.xticks(range(-1,3))
plt.xlabel('y1')
plt.yticks(range(-2,3,2))
plt.ylabel('y2')

legend_handles = [
    plt.scatter([], [], color='red', label='0'),
    plt.scatter([], [], color='blue', label='1')
]

plt.legend(handles=legend_handles, title="Category")

plt.show()

def compute_probabilities(labels):
    total = len(labels)
    counts = Counter(labels)
    #print(counts)
    probabilities = {}
    for label in counts:
        probabilities[label] = counts[label] / total

    return probabilities

label_probs = compute_probabilities(df["y_label"])
print(label_probs)

def compute_entropy(probabilities):
    entropy = 0
    for p in probabilities.values():
        if p > 0:
            entropy += -p * math.log2(p)
    return entropy

def report_entropy(variable, name):
    probs = compute_probabilities(variable)
    entropy = compute_entropy(probs)
    max_entropy = math.log2(len(probs))
    print(f"Entropy of {name}: H({name}) = {entropy:.4f}")
    print(f"Maximum entropy of {name}: H max({name}) = {max_entropy:.4f}")
    print()
    
report_entropy(df["x_label"], "X")
report_entropy(df["y_label"], "Y")

df2 = pd.read_csv("utils_exercise02/data_entropy_mutli.csv")
df2.head()

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Plot X 
scatter1 = axes[0].scatter(df2['x_1'], df2['x_2'], c=df2['x_label'], cmap='tab10', edgecolor='k')
axes[0].set_title("Random Variable X (multi-class)")
axes[0].set_xlabel("x_1")
axes[0].set_ylabel("x_2")

handles1, labels1 = scatter1.legend_elements()
axes[0].legend(handles1, labels1, title="x_label", loc='upper left')

# Plot Y 
scatter2 = axes[1].scatter(df2['y_1'], df2['y_2'], c=df2['y_label'], cmap='tab10', edgecolor='k')
axes[1].set_title("Random Variable Y (multi-class)")
axes[1].set_xlabel("y_1")
axes[1].set_ylabel("y_2")

handles2, labels2 = scatter2.legend_elements()
axes[1].legend(handles2, labels2, title="y_label", loc='upper left')


plt.tight_layout()
plt.show()

report_entropy(df2["x_label"], "X")
report_entropy(df2["y_label"], "Y")

print("Entropy increases as number of classes increases," \
"because the more unique labels a variable can take, the greater the uncertainty in the system.")